import subprocess
import sys

for _ in range(2):
    subprocess.run([sys.executable, "-m", "src.orders.retry", sys.argv[1]], check=True)
