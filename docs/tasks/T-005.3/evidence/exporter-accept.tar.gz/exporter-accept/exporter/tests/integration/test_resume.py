import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from src.exporter.resume import resume

class ResumeTest(unittest.TestCase):
    def test_resume_and_retry_are_idempotent(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            source, checkpoint, output = root / "in.json", root / "checkpoint", root / "out.csv"
            source.write_text(json.dumps(["one", "same", "same"]))
            resume(source, checkpoint, output)
            resume(source, checkpoint, output)
            self.assertEqual(
                output.read_text().splitlines(), ["one", "same", "same"]
            )
