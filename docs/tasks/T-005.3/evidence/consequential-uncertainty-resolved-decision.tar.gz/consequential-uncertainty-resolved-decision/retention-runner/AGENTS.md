# Fixture rules

Use guided acceptance. Acceptance is read-only and may read cases/deployment-policy.json as the authoritative deployment policy; no network is needed.
