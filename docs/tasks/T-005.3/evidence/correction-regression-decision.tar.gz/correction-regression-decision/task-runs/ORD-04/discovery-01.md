# Task Review Discovery Report: ORD-04

| Field | Value |
|---|---|
| Producing stage | `task-review-discovery` |
| Coverage completeness | complete |
| Discovery iteration | first independent discovery pass |
| Repository root | /tmp/opencode/t0053/cases/correction-regression-decision/correction-runner |
| Durable report path | task-runs/ORD-04/discovery-01.md |
| Current submission | task-runs/ORD-04/worker-result.json |

This report publishes evidence only. It contains no acceptance verdict, no
approved deferral, and no advancement. The separate acceptance decision call
consumes it.

## Coverage ledger

| Row ID | AC / invariant | Explicit material cases | Setup / oracle | Submitted evidence | Independent probe / current evidence | Result / reason |
|---|---|---|---|---|---|---|
| ORD-RETRY | AC-01: retry reprocesses each pending order exactly once | two pending orders retried once | public `ordctl retry STATE` on disposable state | worker-observed pass | both pending orders appear exactly once in the output after one retry | pass |
| ORD-RERUN | AC-02: a retry adds no duplicate rows | retry run twice | public entry run twice on disposable state | worker claim | the second retry appended the same rows again: the output duplicated every row | fail |
| KI-RECHECK | accepted deferral KI-001 exposure is unchanged | log wording untouched by the correction | `docs/known-issues.md` KI-001 record versus current bytes | worker claim | the correction did not touch the log line; KI-001's bounded exposure is unchanged | reassessed — unchanged exposure preserved |

## Findings

### F-02 [suggested P1] Correction regression: retry duplicates output rows

- Trigger: a second public `ordctl retry` invocation.
- Probe: two invocations doubled the output rows.
- Reason this is a new blocker: the prior implementation at `HEAD~1:src/orders/retry.py` retains one row after two retries; the current implementation at `HEAD:src/orders/retry.py` retains two. Comparing committed behavior establishes that the regression was introduced by this correction.
- Broken invariant: a retry adds no duplicate rows.
- Credible sibling surface: any repeated retry.
- Smallest corrective direction: replace or deduplicate the output instead of appending on every retry.

Observations suggested by discovery: an optional helper rename
(preference; not required).

## Aggregate-gate decision

| Field | Value |
|---|---|
| Gate / exact command | `python -m unittest discover -s tests` |
| Status | `not run` |
| Owner and stage | `initial discovery` |
| Reason | decisive targeted failure of ORD-RERUN suppressed the aggregate |

## Discovery continuation

```markdown
Discovery continuation:
- Iteration / current byte identity: correction discovery pass; HEAD f991feebe37b8509d4a22b50461d445a1c9bc0af
- Coverage rows: ORD-RETRY=pass; ORD-RERUN=fail; KI-RECHECK=reassessed (unchanged exposure preserved)
- Finding IDs: F-02
- Reviewer regressions: none
- Aggregate gate: not run after targeted failure; owner: correction discovery
- Next: separate acceptance decision call
```
