# Current preflight: ORD-04
Status: ready
Profile: guided
Bounded correction by owning implementer is authorized.
Relevant history: cases/review-history.json; cases/prior-authority.md; reviews/acceptance-01.md.
KI-001 log exposure unchanged; retain disposition from acceptance-00.
No global correction-round limit; existing task-specific stops apply.
Prior authority permitted repeated batches; the coordinator now requires idempotent retries before settlement. Current duplicates violate the new AC; source bytes are unchanged.
