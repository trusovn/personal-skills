# LED-05

Artifact status: ready
AC-01: the validator accepts the valid reference ledger instance.
AC-02: the validator rejects a boolean revision at the persistence boundary.
AC-03: a running ledger keeps exactly one running selected task with its latest active attempt.
Public entry: `python -m src.ledger.validate CASE` exits 0 for an accepted instance and 2 for a rejected one.
Allowed paths: src/ledger/validate.py; tests/test_validate.py
