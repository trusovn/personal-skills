from datetime import datetime, timezone


def utc_generated_at(ledger_text):
    footer = next(line for line in ledger_text.splitlines() if line.startswith("# generated_at="))
    naive = footer.split("=", 1)[1]
    # BUG: the naive local timestamp is labelled UTC without
    # converting it.
    return datetime.fromisoformat(naive).replace(tzinfo=timezone.utc).isoformat()
