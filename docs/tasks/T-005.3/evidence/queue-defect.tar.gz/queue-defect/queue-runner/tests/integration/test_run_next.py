import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from src.queue.run_next import run_next

class RunNextTest(unittest.TestCase):
    def test_first_invocation_and_state(self):
        with TemporaryDirectory() as directory:
            state = Path(directory) / "state.json"
            state.write_text(json.dumps({"tasks": [{"id": "TASK-1", "status": "ready"}]}))
            self.assertEqual(run_next(state), "TASK-1")
            self.assertEqual(json.loads(state.read_text())["tasks"][0]["status"], "running")
