# EXP-08

Artifact status: ready_for_preflight
AC-01: `exportctl resume` appends remaining rows after checkpoint.
AC-02: retry adds no duplicate rows.
Allowed paths: src/exporter/resume.py; tests/integration/test_resume.py
