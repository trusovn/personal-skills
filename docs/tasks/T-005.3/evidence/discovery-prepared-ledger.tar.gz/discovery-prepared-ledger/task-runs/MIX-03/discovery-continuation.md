Discovery continuation:
- Iteration / current byte identity: prior discovery stopped early; bytes unchanged
- Coverage rows: MIX-R1=pass (AC-01 first invocation); MIX-R2=fail (AC-04 second invocation; finding MIX-F1); MIX-R3=blocked (AC-03 concurrency helper absent after preflight; policy forbids replacement); MIX-R4=unchecked (AC-02 retry row unfinished)
- Finding IDs: MIX-F1 (suggested P1)
- Reviewer regressions: none recorded
- Aggregate gate: not run; blocked and unchecked rows present
- Next: continue discovery of the current bytes
