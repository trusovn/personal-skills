# Task Review Discovery Report: ORD-04

| Field | Value |
|---|---|
| Producing stage | `task-review-discovery` |
| Coverage completeness | complete |
| Discovery iteration | first independent discovery pass |
| Repository root | /tmp/opencode/t0053/cases/repeated-review-missed-existing-obligation-decision/correction-runner |
| Durable report path | task-runs/ORD-04/discovery-01.md |
| Current submission | task-runs/ORD-04/worker-result.json |

This report publishes evidence only. It contains no acceptance verdict, no
approved deferral, and no advancement. The separate acceptance decision call
consumes it.

## Coverage ledger
| Row ID | AC / invariant | Explicit material cases | Setup / oracle | Submitted evidence | Independent probe / current evidence | Result / reason |
|---|---|---|---|---|---|---|
| ORD-RETRY | AC-01: one batch per pending order per invocation | one order | public retry | unit pass | one row after first invocation | pass |
| ORD-RERUN | AC-02: a retry adds no duplicate rows. | repeat one order | tests/helpers/replay.py on disposable one-order state | prior row unchecked | two identical rows after replay violate the current no-duplicates AC | fail |
| KI-RECHECK | KI-001 log exposure | one-order log | public retry | accepted deferral | processed 1 orders; still informational | reassessed — unchanged |
## Findings
F-02: missed-existing-obligation. Prior acceptance missed the existing no-duplicates obligation: its one-invocation probe left ORD-RERUN unchecked. Current two-invocation proof establishes the missed violation, not a regression.
Trigger: repeat one pending order; consequence: duplicate processing contrary to the no-duplicates obligation.
Boundary: src/orders/retry.py output; impact: material; exposure: repeated retries; mitigation: none for duplicates. Current proof: helper yields two rows; current AC requires one row.
Optional helper rename is an observation only.
## Aggregate-gate decision
Not run after decisive material probe; owner: current discovery.
## Discovery continuation
- Iteration / current byte identity: repeated review; HEAD 1056dbadacdcd2205be6e648724f03460ad5129d
- Coverage rows: ORD-RETRY=pass; ORD-RERUN=fail; KI-RECHECK=reassessed (unchanged)
- Finding IDs: F-02
- Reviewer regressions: none
- Aggregate gate: not run; owner: current discovery
- Next: separate acceptance decision call
