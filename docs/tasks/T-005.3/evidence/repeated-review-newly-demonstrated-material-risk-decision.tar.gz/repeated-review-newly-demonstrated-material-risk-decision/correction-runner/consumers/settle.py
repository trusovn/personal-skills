import json
import sys
from pathlib import Path

# One processing row causes one $10 settlement charge.
print(10 * len(json.loads(Path(sys.argv[1]).read_text())["output"]))
