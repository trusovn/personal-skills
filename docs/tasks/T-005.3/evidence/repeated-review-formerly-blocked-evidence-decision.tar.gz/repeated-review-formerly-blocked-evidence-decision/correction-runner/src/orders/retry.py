import argparse
import json
from pathlib import Path


def retry(state_path):
    state = json.loads(Path(state_path).read_text())
    rows = [f"{order['id']},processed" for order in state["pending"]]
    # Correction changed replacement to append; repeated retries now duplicate rows.
    state.setdefault("output", []).extend(rows)
    Path(state_path).write_text(json.dumps(state, indent=2) + "\n")
    return len(rows)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="ordctl retry")
    parser.add_argument("state")
    args = parser.parse_args()
    print(f"processed {retry(args.state)} orders")
