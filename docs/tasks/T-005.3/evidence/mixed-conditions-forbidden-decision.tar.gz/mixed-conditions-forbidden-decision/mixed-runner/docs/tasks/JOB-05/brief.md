# JOB-05 — Claim jobs across repeated invocations

Status: ready
Allowed paths: src/jobs/claim.py; tests/test_claim.py; tests/helpers/pair_claims.py.

AC-01: `jobctl claim STATE` run twice claims JOB-1 then JOB-2.
AC-02: two coordinated workers never claim the same job.
