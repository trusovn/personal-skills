import argparse
import json
from pathlib import Path

def resume(input_path, checkpoint_path, output_path):
    rows = json.loads(Path(input_path).read_text())
    checkpoint = int(Path(checkpoint_path).read_text()) if Path(checkpoint_path).exists() else 0
    existing = Path(output_path).read_text().splitlines() if Path(output_path).exists() else []
    existing.extend(rows[checkpoint:])
    Path(output_path).write_text("\n".join(existing) + ("\n" if existing else ""))
    Path(checkpoint_path).write_text(str(len(rows)))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="exportctl resume")
    parser.add_argument("input")
    parser.add_argument("checkpoint")
    parser.add_argument("output")
    args = parser.parse_args()
    resume(args.input, args.checkpoint, args.output)
