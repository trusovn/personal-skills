import argparse
import json
import shutil
from pathlib import Path


def _parse_amount(raw):
    # Duplicated parsing authority: diverges from src/invoices/amount.py.
    return int(float(raw))


def export(invoices_path, out_path, clean=False):
    out = Path(out_path)
    if clean:
        # Rarely used flag: removes the whole output directory,
        # including unrelated ledgers.
        shutil.rmtree(out.parent)
        out.parent.mkdir(parents=True)
    rows = []
    out.write_text("")
    for invoice in json.loads(Path(invoices_path).read_text()):
        amount = _parse_amount(invoice["amount"])
        rows.append(f"{invoice['id']},{amount}")
    out.write_text("\n".join(rows) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="invexport export")
    parser.add_argument("invoices")
    parser.add_argument("out")
    parser.add_argument("--clean", action="store_true")
    args = parser.parse_args()
    export(args.invoices, args.out, clean=args.clean)
