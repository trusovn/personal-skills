The RPT-12B consumer contract requires the reported generation
instant in UTC. The staged input `cases/ledger-local.csv` was
generated in the Berlin deployment (UTC+02:00) at 2026-10-09T09:30:00
local time; its true UTC instant is 2026-10-09T07:30:00+00:00.
