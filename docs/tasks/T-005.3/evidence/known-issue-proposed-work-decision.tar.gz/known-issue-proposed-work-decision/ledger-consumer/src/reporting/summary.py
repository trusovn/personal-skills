def summarize(ledger_text):
    rows = [line for line in ledger_text.splitlines() if line and not line.startswith("#")]
    return len(rows) - 1
