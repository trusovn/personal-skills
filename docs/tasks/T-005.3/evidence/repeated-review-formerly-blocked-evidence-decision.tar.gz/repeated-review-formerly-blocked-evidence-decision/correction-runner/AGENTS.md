# Fixture rules

Acceptance is read-only. The coordinator alone records known issues; accepted deferrals survive while their exposure is unchanged.
