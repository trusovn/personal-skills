# WEB-02 — Cache-bust web assets

Status: ready
Allowed paths: src/web/assets.py.

AC-01: asset URLs change when asset content changes.
