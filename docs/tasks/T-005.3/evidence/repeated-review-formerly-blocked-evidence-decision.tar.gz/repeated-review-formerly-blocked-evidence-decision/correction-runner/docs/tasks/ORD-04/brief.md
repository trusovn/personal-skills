# ORD-04 — Retry pending orders

Status: ready
Allowed paths: src/orders/retry.py; tests/test_retry.py.

AC-01: each `ordctl retry STATE` invocation reprocesses each pending order exactly
once.
AC-02: a retry adds no duplicate rows.
