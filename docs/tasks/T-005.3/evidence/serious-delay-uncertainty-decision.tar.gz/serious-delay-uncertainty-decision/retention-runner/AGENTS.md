# Fixture rules

Acceptance is read-only. Do not invent retention policy; no network or region-registry access is available.
