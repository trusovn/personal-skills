# Current preflight: ORD-04
Status: ready
Profile: guided
Bounded correction by owning implementer is authorized.
Relevant history: cases/review-history.json; cases/prior-authority.md; reviews/acceptance-01.md.
KI-001 log exposure unchanged; retain disposition from acceptance-00.
No global correction-round limit; existing task-specific stops apply.
Prior acceptance missed the existing no-duplicates obligation: its one-invocation probe left ORD-RERUN unchecked. Current two-invocation proof establishes the missed violation, not a regression.
