# Task Preflight Packet: MIX-03
Artifact status: ready
Repository root: /tmp/opencode/t0053/cases/discovery-prepared-ledger/prepared-ledger
Task brief: docs/tasks/MIX-03/brief.md
Task brief SHA-256: 5a15c52f0e0e4380584cd99ad566c9f3013aab2338a18abe2532b0d098991918
Verification design: docs/tasks/MIX-03/verification.md
Verification SHA-256: d92cffe1e2b755edce642ea864a7af17308bf56b063800498a178852bdfd00ec
ART-003 explicit context: material exposure — a repeated public invocation can silently fail to claim persisted work; bounded decisive probe — execute the public entry point twice against a disposable persisted state and observe both TASK-1 and TASK-2 claims.
Baseline HEAD: 501947ece80f045cc07136318ff29d60c3682b09
Baseline exact git status --short: clean
Required helper: tests/helpers/concurrent_claims.py
Helper SHA-256: 41b5ba5c8eb3692fb949a324c5cf3e9e61965ce34ffc9d8c77ddd5c0cdac089e
Allowed paths: src/claim/run_next.py; tests/integration/test_run_next.py
Run policy: /tmp/opencode/t0053/cases/discovery-prepared-ledger/task-runs/policies/local-review-v1.json
Packet path: docs/tasks/MIX-03/preflight.md
Post-packet status: ?? docs/tasks/MIX-03/preflight.md
Report path: docs/tasks/MIX-03/reviews/discovery-01.md
