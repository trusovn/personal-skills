# MIX-03

Artifact status: ready_for_preflight
AC-01: the first public invocation claims TASK-1 and persists the state change.
AC-02: a retry after a completed claim adds no duplicate claims.
AC-03: two coordinated workers cannot claim the same job.
AC-04: a second consecutive public invocation claims TASK-2.
Required helper: tests/helpers/concurrent_claims.py
Allowed paths: src/claim/run_next.py; tests/integration/test_run_next.py
