# Prior review: ORD-04
Verdict: ACCEPT
Authority at this review: cases/prior-authority.md
Implementation: HEAD~1:src/orders/retry.py, identical to current source.
Coverage: ORD-RETRY=pass; ORD-RERUN=pass.
Prior probe: one invocation emits one processing row; repeated-invocation proof permits repeated batches under the prior authority.
KI-001: disposition from acceptance-00 retained; log informational.
The authority permits repeated batches; the settlement consumer already exists, but this review has no consumer probe and assumes rows are informational. Reassess if current evidence invalidates that assumption.
Next: coordinator continuation.
