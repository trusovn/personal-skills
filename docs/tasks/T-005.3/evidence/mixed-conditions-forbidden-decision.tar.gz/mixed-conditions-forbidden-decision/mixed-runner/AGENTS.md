# Fixture rules

Acceptance is read-only. Production corrections follow the run policy.
