# Fixture rules

Discovery may write only the next numbered task-package report. Preserve user notes and use disposable probe state outside the repository.
