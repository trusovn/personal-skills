def total(subtotal):
    return subtotal
