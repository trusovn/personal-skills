# PRICE-02 — Add the approved service fee

Status: ready
Allowed paths: src/pricing.py.
AC-01: `total(100)` returns `110.0`.
Review: immediate and independent after implementation.
