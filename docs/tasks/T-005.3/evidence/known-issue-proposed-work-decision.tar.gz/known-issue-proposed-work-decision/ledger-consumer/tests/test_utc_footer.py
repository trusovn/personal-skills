import unittest
from src.reporting.utc_footer import utc_generated_at

LEDGER = "invoice_id,amount\ninv-1,12.75\n# generated_at=2026-10-09T09:30:00\n"


class UtcFooterTest(unittest.TestCase):
    def test_reports_generated_at_in_utc(self):
        self.assertTrue(utc_generated_at(LEDGER).endswith("+00:00"))
