def parse_amount(raw):
    return float(raw)
