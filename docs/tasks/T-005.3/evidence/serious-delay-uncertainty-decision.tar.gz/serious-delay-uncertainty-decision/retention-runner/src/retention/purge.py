import argparse
import json
import os
from datetime import datetime, timedelta
from pathlib import Path


def purge(state_path):
    years = int(os.environ.get("RETENTION_YEARS", "3"))
    cutoff = datetime.now() - timedelta(days=365 * years)
    state = json.loads(Path(state_path).read_text())
    kept = [invoice for invoice in state["invoices"] if datetime.fromisoformat(invoice["date"]) >= cutoff]
    removed = len(state["invoices"]) - len(kept)
    state["invoices"] = kept
    Path(state_path).write_text(json.dumps(state, indent=2) + "\n")
    return removed


if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="retention purge")
    parser.add_argument("state")
    args = parser.parse_args()
    print(purge(args.state))
