# Verification Design: MIX-03

Source brief: docs/tasks/MIX-03/brief.md
Status: ready

## Coverage summary

| AC | Scenario |
|---|---|
| AC-01 | V-01: first public invocation claims TASK-1 and persists the change |
| AC-02 | V-02: retry after a completed claim adds no duplicate claims |
| AC-03 | V-03: two coordinated workers cannot claim the same job |
