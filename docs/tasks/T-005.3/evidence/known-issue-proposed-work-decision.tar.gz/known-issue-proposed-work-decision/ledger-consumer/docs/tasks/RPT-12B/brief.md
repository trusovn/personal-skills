# RPT-12B — Report the ledger generation instant in UTC

Status: ready
Allowed paths: src/reporting/utc_footer.py; tests/test_utc_footer.py.

AC-01: the report converts the consumed ledger's `generated_at`
footer to a correct UTC instant.
