# Fixture rules

Acceptance is read-only except for the next numbered report under `reviews/`. The human coordinator alone records approved deferrals in `docs/known-issues.md`; discovery and acceptance never write it.
