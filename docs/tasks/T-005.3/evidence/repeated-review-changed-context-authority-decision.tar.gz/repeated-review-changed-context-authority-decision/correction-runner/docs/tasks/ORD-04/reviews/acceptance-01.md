# Prior review: ORD-04
Verdict: ACCEPT
Authority at this review: cases/prior-authority.md
Implementation: HEAD~1:src/orders/retry.py, identical to current source.
Coverage: ORD-RETRY=pass; ORD-RERUN=pass.
Prior probe: one invocation emits one processing row; repeated-invocation proof permits repeated batches under the prior authority.
KI-001: disposition from acceptance-00 retained; log informational.
The then-current authority explicitly permits repeated processing batches; there is no idempotency obligation yet.
Next: coordinator continuation.
