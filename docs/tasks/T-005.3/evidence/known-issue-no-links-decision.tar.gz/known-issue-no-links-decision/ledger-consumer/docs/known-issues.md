# Project known issues

Recorded by the human coordinator from acceptance-approved deferrals.

## KI-001 — INV-07 export footer uses naive local time

- Stable issue ID: KI-001
- Provenance: task INV-07; review acceptance-01; finding INV-M01 (footer `generated_at` naive local time)
- Trigger: any consumer reads the export footer `generated_at` as a timestamp
- Consequence: a UTC-dependent consumer mis-reads the generation instant by the deployment timezone offset
- Evidence: accepted acceptance review with the consumer-contract probe; footer bytes lack a timezone designator
- Impact: bounded — the footer is informational for the declared `report-ledger` consumer
- Likelihood/exposure: only a consumer that requires UTC instants is affected
- Affected boundary: `src/invoices/export.py` footer line
- Affected consumers: `report-ledger` (informational; compatible today)
- Deferral rationale: all required evidence passed; effect bounded; no hidden consumer workaround; the write path is atomic
- Follow-up owner/action: invoices team — switch the footer to UTC before any UTC-dependent consumer lands
- Reassessment conditions: any new consumer requiring UTC `generated_at`, or an export footer schema/migration change
