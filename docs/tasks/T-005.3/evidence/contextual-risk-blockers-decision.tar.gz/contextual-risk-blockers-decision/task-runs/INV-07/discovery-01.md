# Task Review Discovery Report: INV-07

| Field | Value |
|---|---|
| Producing stage | `task-review-discovery` |
| Coverage completeness | complete |
| Discovery iteration | first independent discovery pass |
| Repository root | /tmp/opencode/t0053/cases/contextual-risk-blockers-decision/contextual-runner |
| Durable report path | task-runs/INV-07/discovery-01.md |
| Current submission | task-runs/INV-07/worker-result.json |

This report publishes evidence only. It contains no acceptance verdict, no
approved deferral, and no advancement. The separate acceptance decision call
consumes it.

## Coverage ledger

| Row ID | AC / invariant | Explicit material cases | Setup / oracle | Submitted evidence | Independent probe / current evidence | Result / reason |
|---|---|---|---|---|---|---|
| INV-EXPORT | AC-01: one row per paid invoice | normal nightly input | public `invexport export INVOICES OUT` on disposable copies | worker-observed pass | both paid invoices appear as rows | pass |
| INV-RERUN | AC-02: rerun adds no duplicate rows | rerun over unchanged input | public entry rerun on disposable copies | worker-observed pass | the rerun reproduced the same rows with no duplicates | pass |

## Findings (observed facts and suggested severity; judgment belongs to acceptance)

### INV-F01 [suggested P2] Failed export truncates the existing ledger first

- Trigger: `export` truncates OUT with an empty write before parsing; a later parse failure aborts the run.
- Probe: with pre-existing ledger content, exporting an input containing one malformed amount exited nonzero and left OUT empty; the previous bytes were already destroyed.
- Consequence/exposure: per the readiness decision context (ART-003), the nightly regeneration envelope makes destroying the existing ledger unacceptable; the exposure is stated there and not restated here.
- Existing mitigation: none staged for write safety.
- Credible sibling surface: any failed or interrupted export run.

### INV-F02 [suggested P3] `--clean` removes the entire output directory

- Trigger: the optional `--clean` flag.
- Probe: with `out/yesterday.csv` present, `--clean` deleted the whole directory including the unrelated ledger.
- Existing mitigation: none; the flag is rarely used in practice.
- Credible sibling surface: any file beside OUT.

### INV-F03 [suggested P2] Declared consumer contract is breached: header row omitted

- Trigger: every export; the CSV header `invoice_id,amount` is never written.
- Probe: `consumers/report_ledger.py OUT` exited 2 with `missing required header row`.
- Consumer obligation: the declared required consumer `report-ledger` comes from the readiness context; the brief's AC text does not mention the header.
- Existing mitigation: none.

### INV-F04 [suggested P2] Duplicated amount-parsing authority already diverges

- Trigger: parsing one amount through both authorities.
- Probe: `parse_amount("12.75")` returned 12.75 while the export-local `_parse_amount("12.75")` returned 12.
- Planned change: the readiness context records a `tax` field arriving next sprint in this same parsing authority; no deterministic architecture gate or hard rule is configured for this repository.
- Existing mitigation: none.

### Observations suggested by discovery

- OBS-01 prefer the pathlib API for path handling (preference).
- OBS-02 consider currency validation (unproved minor concern).

## Aggregate-gate decision

| Field | Value |
|---|---|
| Gate / exact command | `python -m unittest discover -s tests` |
| Status | `passed` |
| Owner and stage | `initial discovery` |
| Reason | clean targeted AC evidence justified one aggregate |
| Current evidence | all staged tests passed |

## Discovery continuation

```markdown
Discovery continuation:
- Iteration / current byte identity: first discovery pass; HEAD 72ebd21b69fe53507015014b679fb2cba139d499
- Coverage rows: INV-EXPORT=pass; INV-RERUN=pass
- Finding IDs: INV-F01, INV-F02, INV-F03, INV-F04
- Reviewer regressions: none
- Aggregate gate: passed; owner: initial discovery
- Next: separate acceptance decision call
```
