AC-02: each invocation appends one processing batch; repeated batches are allowed.
