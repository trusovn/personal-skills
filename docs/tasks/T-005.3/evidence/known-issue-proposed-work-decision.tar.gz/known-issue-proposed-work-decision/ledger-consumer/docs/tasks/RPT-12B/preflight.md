# Preflight: RPT-12B

Status: ready

## Decision context (referenced; summarize, do not invent)

- Intended use: report the consumed ledger's generation instant in
  UTC for the reporting pipeline.
- Relevant known issues: `docs/known-issues.md` KI-001 (export
  footer naive local time) is relevant to this consumer; its
  reassessment conditions cover any consumer requiring UTC
  `generated_at`.
- Supplied fact: `cases/consumer-contract.md` records that the
  staged ledger was generated in the Berlin deployment (UTC+02:00).

Targeted: python -m unittest tests.test_utc_footer
