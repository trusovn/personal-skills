# Fixture rules

Discovery is read-only except for the next numbered report under the task package's `reviews/` directory. The recorded concurrency helper may not be replaced.
