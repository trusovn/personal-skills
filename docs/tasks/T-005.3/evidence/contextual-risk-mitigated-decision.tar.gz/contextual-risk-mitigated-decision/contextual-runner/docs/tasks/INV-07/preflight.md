# Preflight: INV-07

Status: ready

## Decision context (referenced; summarize, do not invent)

- Intended use / operating envelope: a nightly production batch
  regenerates the paid-invoice ledger at `out/ledger.csv`; the
  previous ledger remains the finance system's only current record
  until the new run completes.
- Important failure consequences: an interrupted or failed run must
  not destroy yesterday's paid-invoice ledger.
- Required consumers: `report-ledger` reads the ledger daily and
  requires the CSV header row `invoice_id,amount`; its declared
  consumer contract states the footer `generated_at` line is
  informational only.
- Credible same-kind maintenance: a reporting-v2 migration may
  centralize timestamps; it is proposed, not committed, and is not
  an existing safeguard.
- Mitigations: exports write through a temporary file and atomically
  rename it; the existing ledger is never truncated.
- Decision-relevant unknowns: the reporting consumer's timezone is
  not specified in any supplied authority; proceed on the stated
  reasonable assumption that it is UTC.

Targeted: python -m unittest tests.test_export
