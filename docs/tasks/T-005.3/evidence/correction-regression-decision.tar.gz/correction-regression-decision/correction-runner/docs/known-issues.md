# Project known issues

Recorded by the human coordinator from acceptance-approved deferrals.

## KI-001 — ORD-04 retry log wording

- Stable issue ID: KI-001
- Provenance: task ORD-04; review acceptance-01; finding ORD-L01 (retry log says "processed 1 orders")
- Trigger: every retry run logs its completion line
- Consequence: the log line is grammatically wrong; no functional effect
- Evidence: prior accepted review with the log line observed
- Impact: bounded — log wording only
- Likelihood/exposure: every run; no consumer parses the line
- Affected boundary: src/orders/retry.py log line
- Affected consumers: none (log is informational)
- Deferral rationale: all required evidence passed; effect bounded; no hidden workaround
- Follow-up owner/action: orders team — fix the wording in the next logging touch
- Reassessment conditions: any consumer starts parsing the retry log
