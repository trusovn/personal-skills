# Prior review: ORD-04
Verdict: ACCEPT
Authority at this review: cases/prior-authority.md
Implementation: HEAD~1:src/orders/retry.py, identical to current source.
Coverage: ORD-RETRY=pass; ORD-RERUN=unchecked.
Prior probe: one invocation emits one processing row; repeated-invocation proof not performed.
KI-001: disposition from acceptance-00 retained; log informational.
The reviewer accepted on one-invocation evidence and omitted the existing AC-02 repeated-retry obligation.
Next: coordinator continuation.
