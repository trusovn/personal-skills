# Task Review Discovery Report: JOB-05

| Field | Value |
|---|---|
| Producing stage | `task-review-discovery` |
| Coverage completeness | partial — blocked capability |
| Discovery iteration | first independent discovery pass |
| Repository root | /tmp/opencode/t0053/cases/mixed-conditions-authorized-decision/mixed-runner |
| Durable report path | task-runs/JOB-05/discovery-01.md |
| Current submission | task-runs/JOB-05/worker-result.json |

This report publishes evidence only. It contains no acceptance verdict, no
approved deferral, and no advancement. The separate acceptance decision call
consumes it.

## Coverage ledger

| Row ID | AC / invariant | Explicit material cases | Setup / oracle | Submitted evidence | Independent probe / current evidence | Result / reason |
|---|---|---|---|---|---|---|
| JOB-CLAIM | AC-01: two consecutive public invocations claim JOB-1 then JOB-2 | first claim JOB-1; second claim JOB-2 | public `jobctl claim STATE` twice on disposable state | worker-observed unit pass | the first invocation claimed JOB-1; the second returned no claim because JOB-1 is still running; JOB-2 was never claimed | fail |
| JOB-PAIR | AC-02: two coordinated workers never claim the same job | coordinated pair claiming one job | required helper `tests/helpers/pair_claims.py` | worker claim | the preflight-recorded helper is absent from the worktree; no coordinated-pair capability is available under the supplied setup | blocked — required helper unavailable |

## Findings

### F-01 [suggested P1] Second invocation never claims JOB-2

- Trigger: a second public `jobctl claim` invocation after JOB-1 was claimed.
- Probe: the first invocation printed JOB-1; the second printed nothing; JOB-2 was never claimed.
- Broken invariant: repeated public invocations claim successive ready jobs.
- Credible sibling surface: any state with more than one ready job.

## Unresolved material-context question (from readiness context)

Whether claims must be strictly ordered across state files is pending
consumer-contract input; no supplied authority settles it.

## Aggregate-gate decision

| Field | Value |
|---|---|
| Gate / exact command | `python -m unittest discover -s tests` |
| Status | `not run` |
| Owner and stage | `initial discovery` |
| Reason | decisive targeted failure of JOB-CLAIM suppressed the aggregate |

## Discovery continuation

```markdown
Discovery continuation:
- Iteration / current byte identity: first discovery pass; HEAD af71f756587a8c6e68ace88ba3b892e4fee49af4
- Coverage rows: JOB-CLAIM=fail; JOB-PAIR=blocked (required helper unavailable)
- Finding IDs: F-01
- Reviewer regressions: none
- Aggregate gate: not run after targeted failure; owner: initial discovery
- Next: separate acceptance decision call
```
