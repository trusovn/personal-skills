import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from src.invoices.export import export


class ExportTest(unittest.TestCase):
    def test_rows_and_idempotent_rerun(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            invoices = root / "invoices.json"
            invoices.write_text(json.dumps([{"id": "inv-1", "amount": "12.75"}, {"id": "inv-2", "amount": "3.50"}]))
            out = root / "ledger.csv"
            export(invoices, out)
            export(invoices, out)
            self.assertEqual(out.read_text().splitlines(), ["inv-1,12", "inv-2,3"])
