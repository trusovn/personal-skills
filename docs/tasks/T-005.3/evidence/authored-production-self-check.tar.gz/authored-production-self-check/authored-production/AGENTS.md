# Fixture rules

The requested implementation edit is authorized. Any discovery check in the authoring session is self-check only.
