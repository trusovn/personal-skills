import json
import sys
from pathlib import Path

def validate_ledger(ledger):
    if isinstance(ledger.get("revision"), bool) or not isinstance(ledger.get("revision"), int):
        raise ValueError("revision")
    tasks = ledger["tasks"]
    selected_id = ledger.get("selected_task_id")
    selected = next((task for task in tasks if task["id"] == selected_id), None)
    if ledger["status"] == "running":
        running = [task for task in tasks if task["status"] == "running"]
        if len(running) != 1 or selected is None or selected["status"] != "running":
            raise ValueError("running ledger requires exactly one running selected task")
        attempts = selected["attempt_ids"]
        if not attempts or ledger.get("active_attempt_id") != attempts[-1]:
            raise ValueError("active attempt is not the latest")
    return True

if __name__ == "__main__":
    try:
        validate_ledger(json.loads(Path(sys.argv[1]).read_text()))
    except ValueError:
        raise SystemExit(2)
    raise SystemExit(0)
