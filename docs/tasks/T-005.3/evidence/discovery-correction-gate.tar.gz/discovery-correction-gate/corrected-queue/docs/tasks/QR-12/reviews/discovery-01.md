# Task Review Discovery Report: QR-12

Producing stage: `task-review-discovery`
Coverage completeness: `partial — decisive targeted failure and unfinished row`

## Findings

### F-01 [suggested P1] second public invocation fails to claim TASK-2

The second `run-next` invocation returns None while TASK-1 stays
running, so consecutive persisted claims are impossible.

## Coverage

- QR-R1: AC-01 first invocation — pass (independently observed TASK-1 claim and persisted state change)
- QR-R2: AC-01 second invocation — fail (second invocation returned None; finding F-01)
- QR-R3: AC-02 retry row — unchecked (not reached before the pass stopped)

## Aggregate gate

`python -m unittest discover -s tests` — not run; decisive targeted
failure; owner: fresh correction discovery after clean targeted
evidence.

Next: correction, then fresh discovery of the corrected bytes.
