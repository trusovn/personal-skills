AC-02: a retry adds no duplicate rows.
