# Task Preflight Packet: QR-12
Artifact status: ready
Repository root: /tmp/opencode/t0053/cases/queue-defect/queue-runner
Task brief: docs/tasks/QR-12/brief.md
Task brief SHA-256: fb3e107b3747d051de71119718f51581f3652036fa22258ce22ff74ac16b2279
Baseline HEAD: c5f1a47b8501d800408254cd1a4135361cf4e49b
Baseline exact git status --short: clean
Allowed paths: src/queue/run_next.py; tests/integration/test_run_next.py
Run policy: /tmp/opencode/t0053/cases/queue-defect/task-runs/policies/local-review-v1.json
Packet path: docs/tasks/QR-12/preflight.md
Post-packet status: ?? docs/tasks/QR-12/preflight.md
Report path: docs/tasks/QR-12/reviews/discovery-01.md
AC-01 requires an independent two-invocation public-entry probe in disposable state.
Legacy finding: trace guards that compare against any initially running task.
