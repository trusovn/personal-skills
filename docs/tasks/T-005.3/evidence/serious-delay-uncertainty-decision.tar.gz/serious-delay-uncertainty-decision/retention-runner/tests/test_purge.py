import json
from datetime import datetime, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from src.retention.purge import purge


class PurgeTest(unittest.TestCase):
    def test_purge_honors_the_configured_horizon(self):
        with TemporaryDirectory() as directory:
            state = Path(directory) / "state.json"
            old = (datetime.now() - timedelta(days=1460)).isoformat()
            recent = (datetime.now() - timedelta(days=365)).isoformat()
            state.write_text(json.dumps({"invoices": [{"id": "INV-OLD", "date": old}, {"id": "INV-NEW", "date": recent}]}))
            self.assertEqual(purge(state), 1)
            remaining = [invoice["id"] for invoice in json.loads(state.read_text())["invoices"]]
            self.assertEqual(remaining, ["INV-NEW"])
