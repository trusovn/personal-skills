unstaged continuation of user note
