import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from src.queue.run_next import run_next

class RunNextTest(unittest.TestCase):
    def state(self, directory):
        path = Path(directory) / "state.json"
        path.write_text(json.dumps({"tasks": [
            {"id": "TASK-1", "status": "ready"},
            {"id": "TASK-2", "status": "ready"},
        ]}))
        return path

    def test_first_invocation_and_state(self):
        with TemporaryDirectory() as directory:
            state = self.state(directory)
            self.assertEqual(run_next(state), "TASK-1")

    def test_second_invocation_claims_next_task(self):
        with TemporaryDirectory() as directory:
            state = self.state(directory)
            self.assertEqual(run_next(state), "TASK-1")
            self.assertEqual(run_next(state), "TASK-2")

    def test_retry_after_completion_adds_no_duplicate(self):
        with TemporaryDirectory() as directory:
            state = self.state(directory)
            self.assertEqual(run_next(state), "TASK-1")
            self.assertEqual(run_next(state), "TASK-2")
            self.assertIsNone(run_next(state))
