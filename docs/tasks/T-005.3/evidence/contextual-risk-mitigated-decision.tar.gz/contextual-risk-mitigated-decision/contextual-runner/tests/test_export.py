import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from src.invoices.export import export


class ExportTest(unittest.TestCase):
    def test_rows_header_and_idempotent_rerun(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            invoices = root / "invoices.json"
            invoices.write_text(json.dumps([{"id": "inv-1", "amount": "12.75"}, {"id": "inv-2", "amount": "3.5"}]))
            out = root / "ledger.csv"
            export(invoices, out)
            export(invoices, out)
            lines = out.read_text().splitlines()
            self.assertEqual(lines[:3], ["invoice_id,amount", "inv-1,12.75", "inv-2,3.5"])
            self.assertTrue(lines[3].startswith("# generated_at="))
