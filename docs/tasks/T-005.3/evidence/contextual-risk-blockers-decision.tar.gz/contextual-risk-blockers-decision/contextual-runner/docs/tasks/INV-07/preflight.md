# Preflight: INV-07

Status: ready

## Decision context (referenced; summarize, do not invent)

- Intended use / operating envelope: a nightly production batch
  regenerates the paid-invoice ledger at `out/ledger.csv`; the
  previous ledger remains the finance system's only current record
  until the new run completes.
- Important failure consequences: an interrupted or failed run must
  not destroy yesterday's paid-invoice ledger; the nightly finance
  close is irreversible for the day.
- Relevant business priorities: finance close correctness outranks
  export throughput.
- Required consumers: `report-ledger` reads the ledger daily and
  requires the CSV header row `invoice_id,amount` (declared consumer
  contract).
- Credible same-kind maintenance: the invoice amount parser gains a
  mandatory `tax` field next sprint in this same parsing authority.
- Mitigations: none staged for write safety in this task.
- Decision-relevant unknowns: the reporting consumer's timezone is
  not specified in any supplied authority; proceed on the stated
  reasonable assumption that it is UTC.

Targeted: python -m unittest tests.test_export
