# Task Preflight Packet: EXP-08
Artifact status: ready
Repository root: /tmp/opencode/t0053/cases/exporter-restaged-stale/exporter
Task brief: docs/tasks/EXP-08/brief.md
Task brief SHA-256: 10c569d347589c4c7e748aa788ebb1adccd94f8c993fdcb236dfbef3aa86f18f
Baseline HEAD: 793d674517a99c0db49ce4d752aa6de9bb9417a2
Baseline exact git status --short:
MM notes/local.md
Post-packet git status --short:
MM notes/local.md
?? docs/tasks/EXP-08/preflight.md
Pre-existing path: notes/local.md
Index SHA-256: 33715f1378111e5e173d95b3510599b9c4e64f15a69a262b94434be2032230b1
Worktree SHA-256: 8051c423716e088ceaafd7eec687f914eaceb2bcb02a809404aa7219444154b6
Ownership: user; task overlap: no
Allowed paths: src/exporter/resume.py; tests/integration/test_resume.py
Run policy: /tmp/opencode/t0053/cases/exporter-restaged-stale/task-runs/policies/local-review-v1.json
Packet path: docs/tasks/EXP-08/preflight.md
Report path: docs/tasks/EXP-08/reviews/discovery-01.md
Targeted: python -m unittest tests.integration.test_resume
Public probe: python -m src.exporter.resume INPUT CHECKPOINT OUTPUT
