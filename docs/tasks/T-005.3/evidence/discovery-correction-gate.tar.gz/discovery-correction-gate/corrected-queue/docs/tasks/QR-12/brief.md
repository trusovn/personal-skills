# QR-12

Artifact status: ready_for_preflight
AC-01: two consecutive public invocations persist state and claim TASK-1 then TASK-2.
AC-02: a retried invocation after a completed claim adds no duplicate claims.
Allowed paths: src/queue/run_next.py; tests/integration/test_run_next.py
