# Preflight: JOB-05

Status: ready

## Decision context (referenced; summarize, do not invent)

- Intended use: the job runner claims queued jobs one at a time across
  repeated public invocations.
- Required proof: AC-02 needs the coordinated pair helper
  `tests/helpers/pair_claims.py` (SHA-256 726021df4c7fe24dca18b2b15bb06918677d3f3374c09f333c302cc0d4bcbf0e).
- Decision-relevant unknown (unresolved): whether claims must be strictly
  ordered across state files is pending; the consumer contract is awaiting
  coordinator input and no supplied authority settles it.
- Run policy: /tmp/opencode/t0053/cases/mixed-conditions-forbidden-decision/task-runs/policies/local-review-mixed.json

Targeted: python -m unittest tests.test_claim
