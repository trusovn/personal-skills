import json
from pathlib import Path
import unittest

from src.ledger.validate import validate_ledger

ROOT = Path(__file__).resolve().parents[1]


class ValidateTest(unittest.TestCase):
    def test_valid_reference_instance_accepted(self):
        ledger = json.loads((ROOT / "cases" / "valid.json").read_text())
        self.assertTrue(validate_ledger(ledger))

    def test_running_coherence(self):
        ledger = json.loads((ROOT / "cases" / "valid.json").read_text())
        ledger["active_attempt_id"] = "A-9"
        with self.assertRaises(ValueError):
            validate_ledger(ledger)
