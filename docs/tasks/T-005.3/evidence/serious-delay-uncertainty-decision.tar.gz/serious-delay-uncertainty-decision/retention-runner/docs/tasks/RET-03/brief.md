# RET-03 — Purge expired invoices

Status: ready
Allowed paths: src/retention/purge.py; tests/test_purge.py.

AC-01: `retention purge STATE` removes invoices older than the
retention horizon and keeps the rest.
