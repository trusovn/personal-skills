# Preflight: RPT-12A
Status: ready
Profile: guided
Required consumer: row counts only; footer informational, unchanged.
Relevant record: docs/known-issues.md KI-001; compatibility/exposure unchanged.
Follow-up: cases/follow-up.json records committed work, not deployed.
Existing mitigation: row-count consumer ignores the footer, independent of future work.
Priority: unchanged.
Missing optional links mean unknown relationships.
Targeted: supplied row-count consumer probe on cases/ledger-local.csv
