import unittest

from src.pricing import total


class PricingTest(unittest.TestCase):
    def test_approved_service_fee(self):
        self.assertEqual(total(100), 110.0)
