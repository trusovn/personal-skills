# Fixture rules

Acceptance is read-only. The coordinator alone records known issues; a relevant later review reassesses them against this task's exposure and obligations.
