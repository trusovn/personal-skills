# RPT-12A — Summarize ledger row counts

Status: ready
Allowed paths: src/reporting/summary.py.

AC-01: the summary reports the ledger's data row count; the footer
line is informational text only.
