# Current preflight: ORD-04
Status: ready
Profile: guided
Bounded correction by owning implementer is authorized.
Relevant history: cases/review-history.json; cases/prior-authority.md; reviews/acceptance-01.md.
KI-001 log exposure unchanged; retain disposition from acceptance-00.
No global correction-round limit; existing task-specific stops apply.
ACs still permit repeated batches. New proof of the existing settlement consumer shows two $10 charges for one $10 order, a material double-charge risk despite passing ACs. Operating context and authority are unchanged; the prior report did not assess this exposure. Source bytes are unchanged.
