import argparse
import json
from pathlib import Path


def claim(path):
    state = json.loads(Path(path).read_text())
    # BUG: refuses to claim while any job is running, so the second
    # public invocation never claims JOB-2.
    if any(job["status"] == "running" for job in state["jobs"]):
        return None
    job = next((item for item in state["jobs"] if item["status"] == "ready"), None)
    if job is None:
        return None
    job["status"] = "running"
    Path(path).write_text(json.dumps(state, indent=2) + "\n")
    return job["id"]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="jobctl claim")
    parser.add_argument("state")
    args = parser.parse_args()
    claimed = claim(args.state)
    if claimed:
        print(claimed)
