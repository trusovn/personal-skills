# Prior review: ORD-04
Verdict: INCONCLUSIVE
Authority at this review: cases/prior-authority.md
Implementation: HEAD~1:src/orders/retry.py, identical to current source.
Coverage: ORD-RETRY=pass; ORD-RERUN=blocked.
Prior probe: one invocation emits one processing row; repeated-invocation proof unavailable.
KI-001: disposition from acceptance-00 retained; log informational.
The missing replay helper prevents a decisive repeated-invocation result; recover evidence before advancement.
Next: recover replay evidence.
