# INV-07 — Export the paid-invoice ledger

Status: ready
Allowed paths: src/invoices/export.py; src/invoices/amount.py; tests/test_export.py.

AC-01: `invexport export INVOICES OUT` writes one row per paid invoice to OUT.
AC-02: a rerun over the same input adds no duplicate rows.
