import argparse
import json
import os
from datetime import datetime
from pathlib import Path

from src.invoices.amount import parse_amount


def export(invoices_path, out_path):
    out = Path(out_path)
    rows = ["invoice_id,amount"]
    for invoice in json.loads(Path(invoices_path).read_text()):
        rows.append(f"{invoice['id']},{parse_amount(invoice['amount'])}")
    # Bounded non-material defect: the informational footer uses the
    # server's naive local time instead of UTC.
    rows.append(f"# generated_at={datetime.now().isoformat()}")
    temporary = out.with_name(out.name + ".tmp")
    temporary.write_text("\n".join(rows) + "\n")
    os.replace(temporary, out)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="invexport export")
    parser.add_argument("invoices")
    parser.add_argument("out")
    args = parser.parse_args()
    export(args.invoices, args.out)
