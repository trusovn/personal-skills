import argparse
import json
from pathlib import Path

def run_next(state_path):
    path = Path(state_path)
    state = json.loads(path.read_text())
    task = next((item for item in state["tasks"] if item["status"] == "ready"), None)
    if task is None:
        return None
    task["status"] = "running"
    path.write_text(json.dumps(state))
    return task["id"]

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("state")
    args = parser.parse_args()
    claimed = run_next(args.state)
    if claimed:
        print(claimed)
