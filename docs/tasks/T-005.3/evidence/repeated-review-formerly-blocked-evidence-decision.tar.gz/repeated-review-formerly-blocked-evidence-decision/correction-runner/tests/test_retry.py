import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from src.orders.retry import retry


class RetryTest(unittest.TestCase):
    def test_retry_processes_pending_orders(self):
        with TemporaryDirectory() as directory:
            state = Path(directory) / "state.json"
            state.write_text(json.dumps({"pending": [{"id": "ORD-1"}, {"id": "ORD-2"}], "output": []}))
            self.assertEqual(retry(state), 2)
            output = json.loads(state.read_text())["output"]
            self.assertEqual(output, ["ORD-1,processed", "ORD-2,processed"])
