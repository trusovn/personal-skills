# Preflight: ORD-04 (correction cycle)

Status: ready

## Decision context (referenced; summarize, do not invent)

- Intended use: the order runner retries pending orders after
  failures.
- Relevant known issues: `docs/known-issues.md` KI-001 (retry log
  wording), recorded by the coordinator from the prior accepted
  review; this correction does not touch the log line, so its
  exposure is unchanged.
- Stop rules: existing task-specific stops remain in force; no
  global correction-round limit exists.

Targeted: python -m unittest tests.test_retry
