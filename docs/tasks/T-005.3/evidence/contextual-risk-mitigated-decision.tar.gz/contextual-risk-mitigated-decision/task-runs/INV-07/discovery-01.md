# Task Review Discovery Report: INV-07

| Field | Value |
|---|---|
| Producing stage | `task-review-discovery` |
| Coverage completeness | complete |
| Discovery iteration | first independent discovery pass |
| Repository root | /tmp/opencode/t0053/cases/contextual-risk-mitigated-decision/contextual-runner |
| Durable report path | task-runs/INV-07/discovery-01.md |
| Current submission | task-runs/INV-07/worker-result.json |

This report publishes evidence only. It contains no acceptance verdict, no
approved deferral, and no advancement. The separate acceptance decision call
consumes it.

## Coverage ledger

| Row ID | AC / invariant | Explicit material cases | Setup / oracle | Submitted evidence | Independent probe / current evidence | Result / reason |
|---|---|---|---|---|---|---|
| INV-EXPORT | AC-01: one row per paid invoice | normal nightly input | public `invexport export INVOICES OUT` on disposable copies | worker-observed pass | every paid invoice appears as a row behind the required header | pass |
| INV-RERUN | AC-02: rerun adds no duplicate rows | rerun over unchanged input | public entry rerun on disposable copies | worker-observed pass | the rerun reproduced the same rows with no duplicates | pass |

## Findings (observed facts and suggested severity; judgment belongs to acceptance)

### INV-M01 [suggested P3] Footer timestamp uses naive local time

- Trigger: every export writes the informational `# generated_at` footer from `datetime.now()`.
- Probe: the exported footer carries no timezone designator, so it is a naive local timestamp rather than a UTC instant.
- Compatibility probe: `consumers/report_ledger.py OUT` exited 0; the declared consumer treats the footer as informational only (readiness context).
- Existing mitigation: the write path is atomic (temporary file plus rename); the previous ledger is never truncated.
- Bounded effect: no declared consumer currently parses the footer.
- Planned change note: the reporting-v2 migration is proposed, not committed; it is not an existing safeguard.
- Credible sibling surface: any consumer that starts parsing the footer.

### Observations suggested by discovery

- OBS-01 prefer the pathlib API for path handling (preference).
- OBS-02 consider currency validation (unproved minor concern).

## Aggregate-gate decision

| Field | Value |
|---|---|
| Gate / exact command | `python -m unittest discover -s tests` |
| Status | `passed` |
| Owner and stage | `initial discovery` |
| Reason | clean targeted AC evidence justified one aggregate |
| Current evidence | all staged tests passed |

## Discovery continuation

```markdown
Discovery continuation:
- Iteration / current byte identity: first discovery pass; HEAD b5b1d61a602945b304207edafe881fe6336b3d7e
- Coverage rows: INV-EXPORT=pass; INV-RERUN=pass
- Finding IDs: INV-M01
- Reviewer regressions: none
- Aggregate gate: passed; owner: initial discovery
- Next: separate acceptance decision call
```
