import sys
from pathlib import Path

lines = Path(sys.argv[1]).read_text().splitlines()
if not lines or lines[0] != "invoice_id,amount":
    print("report-ledger: missing required header row")
    raise SystemExit(2)
print("report-ledger: ok")
